# EVA suit metabolic allowance

Three independently editable activity-only factors replace the single allowance: `Suit.LightFactor`, `Suit.ManualFactor`, and `Suit.WalkingFactor`. All default to 1.20 as preliminary assumptions, not literature-calibrated coefficients.

| Current label | Task class | Gravity factor | Suit factor |
|---|---|---|---|
| Nominal | Light | 1 | LightFactor |
| Above Nominal | Manual | 1 | ManualFactor |
| Exercise - Resistance | Manual | 1 | ManualFactor |
| Exercise - Aerobic | Walking (assumed traverse proxy) | C_w_M / C_w_E | WalkingFactor |

`M_physical = M_rest + k_task * K_g_task * max(M_mapped - M_rest, 0)`.

RestingMetabolicRate_W = 316/3.6 = 87.78 W is the BVAD sleep-rate proxy, not a measured basal metabolic rate. NominalMetabolicRate_W = 500/3.6 = 138.89 W is the separate awake reference used by the LCG cooling allocation (BVAD Rev. 2, Tables 3-24/3-25, printed p. 49). The resting component is unchanged by task corrections. At LightFactor = 1.2, nominal activity becomes 149.11 W before FOS (164.02 W with FOS = 1.1). Only walking uses the existing speed/gravity relation. The suit multiplier now acts on gravity-adjusted activity, replacing the former additive Earth-activity penalty. The source mapping still defines Above Nominal as 80% of the resistance source rate. Unknown task labels raise an error. Metabolic_Task_Mapping exposes the classification, factors and rates for every input row.

## Evidence and interpretation

- Carr and Newman (2007), *Space suit bioenergetics: framework and analysis of unsuited and suited activity*, DOI: 10.3357/asem.1952.2007. https://pubmed.ncbi.nlm.nih.gov/18018432/ identifies pressure, gravity, speed, slope and suit configuration as drivers. This supports modelling a suit contribution, but does not establish 20% as a common constant.
- Diaz-Artiles et al. (2019), *SmartSuit: Hybrid, Intelligent, and Highly Mobile EVA Spacesuit for Next Generation Exploration Missions*, NASA NIAC Phase I report, Table 1, p. 15. https://www.nasa.gov/wp-content/uploads/2019/04/niac_2019_phi_diazartiles_smartsuit_tagged.pdf reports simulated walking expenditures of 556 kcal/h unsuited, 957 in the EMU and 842 in SmartSuit. Ratios imply approximately 72% and 51% higher total expenditure respectively. These are simulation-specific walking results, not measured Mars EVA multipliers; they show why 20% cannot be described as conservative for every suit/task.
- Kluis and Diaz-Artiles (2021), *Revisiting decompression sickness risk and mobility in the context of the SmartSuit, a hybrid planetary spacesuit*, npj Microgravity 7, 46. https://doi.org/10.1038/s41526-021-00175-3 examines pressure and assistance effects on mobility/metabolic expenditure. Its suit-specific simulations further support pressure/mobility dependence, rather than a universal allowance.

Retaining 20% is defensible only as an explicit placeholder for an unspecified future suit during preliminary trades. Validate it using matched suited/unsuited tasks at representative pressure, gravity, speed and carried mass. Exploratory factors 1.0, 1.2, 1.5 and 1.75 can expose sizing dependence; these are analyst-selected scenarios, not confidence bounds. Avoid adding the allowance to source profiles already measured during suited EVA.

## Scope in this script

JOS-3 now receives PhysicalMetabolicRate_W so task corrections affect moisture, air temperature and downstream RH hardware sizing. DesignMetabolicRate_W includes FOS for the displayed design metabolic summary. FOS is not fed into physiology; it continues to scale the simulated moisture requirements separately. The source metabolic profiles remain available for comparison. These corrections assume the mapped input rates do not already contain an EVA suit penalty.

Activity-only factors previously derived by subtracting 143 W must be recalculated before use with the new resting reference. The current factors remain assumed 1.20 values. JOS-3 retains its own physiological basal-rate calculation; the sleep proxy changes profile scaling only.
