% Raaghav Lele, Zach Alles
% Date created: 10/19/2026
% Thermal Component Model 


% This code plots a graph of heat rejection capacity for a given set up of
% radiator temperatures. 
clc
clear
close all

%% Part zero: Properties and geometry
fprintf("System Inputs/Output Analysis \n\n")
water_cp = 4184;       % J/(kg K)
water_rho = 1000;      % kg/m^3
sigma = 5.670374419e-8; % W/(m^2 K^4)

H = 0.50; % m
W = 0.33; % m
D = 0.30; % m

% Face order: rear, right, left, top, bottom
A_faces = [H*W; H*D; H*D; W*D; W*D];
Arad = sum(A_faces);   % 0.663 m^2

% Flat terrain; no body blockage, view factors
F_ground = [0.5; 0.5; 0.5; 0; 1];
F_sky = 1 - F_ground;

A_ground_weighted = sum(A_faces .* F_ground);
A_sky_weighted = sum(A_faces .* F_sky);

%% Metabolic input

load("MetData.mat")
Metabolic_rates = MetData.metrate; % Column vector, W
time = MetData.time;

% Preliminary assumption: all metabolic heat reaches cooling system
Q_electrical = 10; % average assumption
Q_internal = Metabolic_rates + Q_electrical;
%fprintf("Average internal heat generation due to metabolic and electical sources is %.2f Watts\n",mean(Q_internal))


%% Environmental cases

% Idealized 2D Sun path, not a calculated Mars time history:
% 0 deg = Sun at rear horizon
% 90 deg = overhead
% 180 deg = Sun at front horizon
theta = linspace(0,180,181); % Row vector

% Optical properties
alpha_solar = 0.2;
epsilon_rad = 0.9; 
alpha_IR = epsilon_rad;

epsilon_ground = 0.95;
rho_ground = 0.2;   % average Martian ground albedo

% Environmental temperatures
T_ground = 235; % K; prescribed ground-temperature scenario
T_air = 210;    % K; prescribed air-temperature scenario
T_sky = 170;    % K; EFFECTIVE radiative sky temperature
T_Rad_C = linspace(7,100,100);  % K; trial radiator surface temperature Assume Skin temp is 307 and delta of 5 K drop from skin to Radiator 
T_Rad_K = 273 + T_Rad_C;
h = 1;         % W/(m^2 K); prescribed convection coefficient - Assumed from Hayman 2025 paper based on wind speed of 5 m/s


%% Direct solar heating

% Assumed direct-normal irradiance; from ASEN 5158 lecture notes
q_solar_DNI = 175; % W/m^2

A_rad_cross = H*W .* max(0, cosd(theta)) ...
            + W*D .* sind(theta); 

Q_solar = alpha_solar .* A_rad_cross .* q_solar_DNI;
Q_solar_mean = mean(Q_solar);
%fprintf("Direct normal incident Solar is %.2f Watts\n",mean(Q_solar))

%% Reflected solar heating: albedo

% Direct sunlight on horizontal ground; diffuse sunlight neglected
G_solar_ground = q_solar_DNI .* sind(theta);

Q_albedo = alpha_solar .* rho_ground .* ...
           G_solar_ground .* A_ground_weighted;
Q_albedo_mean = mean(Q_albedo);
%fprintf("Albedo is %.2f Watts\n",mean(Q_albedo))

%% Absorbed thermal infrared

% Ground emission only; reflected atmospheric IR neglected
Q_ground_IR_abs = alpha_IR * epsilon_ground * sigma * ...
                  T_ground^4 * A_ground_weighted;

%fprintf("Ground IR is %.2f Watts\n",mean(Q_ground_IR_abs))

% Effective sky temperature represents incident sky IR
Q_sky_IR_abs = alpha_IR * sigma * ...
               T_sky^4 * A_sky_weighted;
%fprintf("Sky IR is %.2f Watts\n",mean(Q_sky_IR_abs))

%% Heat leaving radiator

Q_conv = h * Arad * (T_Rad_K - T_air); % Signed: positive outward
%fprintf("Heat lost to Atmospheric Convection assuming 5 m/s windspeed is %.2f Watts\n",Q_conv)

Q_IR_emit = epsilon_rad * sigma * Arad * T_Rad_K.^4;
%fprintf("IR emitted from  the radiator is %.2f Watts\n",Q_IR_emit)
fprintf("\n")

%% System balance


Q_inputs = Q_solar_mean + Q_albedo_mean ...
                  + Q_ground_IR_abs + Q_sky_IR_abs;
Q_inputs = Q_inputs.*ones(1,100);
% Net heat that the radiator can remove from internal sources
% One value per solar-position case
Q_cooling_available = Q_IR_emit + Q_conv - Q_inputs;

fprintf("Average Cooling available is %.2f Watts\n",mean(Q_cooling_available))

Q_cooling_available_nowind = Q_cooling_available - Q_conv;

figure()
hold on
title("Radiator Heat Rejection Capacity on Mars")
plot(T_Rad_C,Q_cooling_available_nowind,linewidth=2)
plot(T_Rad_C,Q_cooling_available,linewidth=2)
xlabel('Radiator Temperature (C)')
ylabel('Heat Rejected Capability in Martian Environment')
legend('Radiation only','Radiation and Martian Wind','Location','northwest')
xlim([6 125])
grid on
hold off
