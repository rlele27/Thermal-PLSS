% Raaghav Lele, Zach Alles
% Date created: 10/19/2026
% Thermal Component Model 

clc
clear
close all


% garage_code = 1027; 
% address = '4505 gretna st besthesda';

%% ----------------------- File Inputs ------------------------------------

% For this script to run, make sure the following files are in the same
% folder
% 1) "MetData.mat"
% 2) "EVA_Data.mat"


%% Model inputs and constants
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        Load Metabolic EVA data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

%Load original met data
load("MetData.mat")
Metabolic_rates = MetData.metrate; % Column vector, W
time = MetData.time;

% Preliminary assumption: all metabolic heat reaches cooling system
Q.electrical = 10; % average assumption
Q.internal = Metabolic_rates + Q.electrical;
fprintf("Average internal heat generation due to metabolic and electical sources is %.2f Watts\n",mean(Q.internal))

% load high fidelity EVA data
load("EVA_Data.mat")
rH_cooling =190; %W peak, dumped into LCG water loop
LCGCooling_W = Data.Simulation.OffNominal.Physiology.LCGCooling_W;
LCGOutletTemperature_C = Data.Simulation.OffNominal.Physiology.LCGOutletTemperature_C;
LCGInletTemperature_C = Data.Simulation.OffNominal.Physiology.LCGInletTemperature_C;
LCGMassFlow_kg_s = Data.Simulation.OffNominal.Physiology.LCGMassFlow_kg_s; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                          Define Constants
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% substance properties and universal constants
const.water_cp = 4184;       % J/(kg K)
const.water_rho = 1000;    % kg/m^3
const.sigma = 5.670374419e-8; % W/(m^2 K^4)

% Radiator specs 
rad_specs.H = 0.50; % m
rad_specs.W = .33;  % m
rad_specs.D = .30;  % m
rad_specs.A_faces = [rad_specs.H*rad_specs.W; rad_specs.H*rad_specs.D;...
                              rad_specs.H*rad_specs.D; rad_specs.W*rad_specs.D; ...
                              rad_specs.W*rad_specs.D]; % Face order: rear, right, left, top, bottom
rad_specs.Arad = sum(rad_specs.A_faces);   % 0.663 m^2
rad_specs.alpha_solar = 0.2;% Optical properties
rad_specs.epsilon_rad = 0.9;
rad_specs.F_ground = [0.5; 0.5; 0.5; 0; 1];% Calc View factors for the PLSS
rad_specs.F_sky = 1 - rad_specs.F_ground; % Flat terrain; no body blockage, view factors
rad_specs.A_ground_weighted = sum(rad_specs.A_faces .* rad_specs.F_ground);
rad_specs.A_sky_weighted = sum(rad_specs.A_faces .* rad_specs.F_sky); 



% Mars environmental Constants (validate temp assumptions for 27.5 S
% latitude)
envir_const.alpha_IR = rad_specs.epsilon_rad;
envir_const.epsilon_ground = 0.95;
envir_const.rho_ground = 0.2; % average Martian ground albedo
envir_const.T_ground = 235; % K; prescribed ground-temperature scenario
envir_const.T_air = 210;    % K; prescribed air-temperature scenario
envir_const.T_sky = 170;    % K; EFFECTIVE radiative sky temperature
envir_const.h = 1;           % Assumed for wind speed of 5 m/s Schauss/Hayman 2025
envir_const.q_solar_DNI = 175; % W/m^2 | Assumed direct-normal irradiance; from ASEN 5158 lecture notes


%% I/O model
T_Rad = 273+14;


[Q, theta] = radiator_output(T_Rad, const, rad_specs, envir_const, Q);


% Plot I/O bar chart
IOs = [mean(Q.solar); mean(Q.albedo); mean(Q.ground_IR_abs); ...
           mean(Q.sky_IR_abs); Q.conv; Q.IR_emit];
    
    
labels = ["Incident Solar", "Albedo", "Ground IR", "Sky IR", ...
              "Convection Losses (wind)", "Radiator Output"];
    
    
colors = lines(numel(IOs));  % One distinct color per bar
    
% Plot bar chart for I/O of thermal system
figure()
hold on
    
for i = 1:numel(IOs)
        bar(i, IOs(i), ...
            "FaceColor", colors(i,:), ...
            "DisplayName", labels(i));
end
    
hold off
xticks(1:numel(IOs))
xticklabels(labels)
xtickangle(25)
xlabel("System Thermal Inputs and Outputs (average magnitude)")
ylabel("Watts")
title("Martian PLSS Thermal Inputs and Outputs Model")
legend("show", "Location", "northwest")
grid on
    
% Rows = metabolic samples; columns = solar-position cases
Q.shortfall = Q.internal - Q.cooling_available;
    
% Positive shortfall: additional cooling/storage required
% Negative shortfall: excess cooling capacity at prescribed T_Rad
    
% Gross IR emission required to balance each combination
Q.IR_required = Q.internal + Q.solar + Q.albedo ...
                  + Q.ground_IR_abs + Q.sky_IR_abs - Q.conv;
    
    
% Calculate short fall in worst possible sun angle scenario
Q.shortfall_design = Metabolic_rates(:) ...
                       - min(Q.cooling_available);
    
% Cooling Shortfall across the EVA
figure
plot(time(:), Q.shortfall_design, 'LineWidth', 1.5);
yline(0, 'k--')
% Add manually positioned label
text(5.7, 15, ...
        sprintf('Cooling capacity = %.2f W', mean(Q.cooling_available)), ...
        'HorizontalAlignment', 'left', ...
        'FontSize', 10);
xlabel('EVA time [hr]');
ylabel('Cooling shortfall [W]');
title('Cooling shortfall across nominal EVA');
grid on
    
% Plot Heat loads at various sun angles
% unique sorts the rates and returns their original row indices
[metabolic_unique, idx] = unique(Metabolic_rates);
Q.unique = Q.shortfall(idx, :);
    
figure
contourf(metabolic_unique, theta, Q.unique.', ...
             30, 'LineColor', 'none');
    
hold on
contour(metabolic_unique, theta, Q.unique.', ...
            [0 0], 'k', 'LineWidth', 2);
    
cb = colorbar;
cb.Label.String = 'Cooling shortfall [W]';
xlabel('Metabolic heat load [W]');
ylabel('Idealized Sun-path angle [deg]');
title('Cooling shortfall versus metabolic load and Sun angle');
colormap(turbo)
grid on




%% Part two: Heat Transport and Mass Flow 
% This section will follow that heat acquisition section and the results
% from the previous section will be used as an input. Heat that is lost or
% created through pipe flow will be modeled. Things such as heat loss through an insulation layer,
% major and minor presssure losses, and laminar v turbulent flow will be
% modeled. Heat added/lost through pumps and valves will be considered

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assumptions:
% - Air in the PLSS is between 12-30 deg C. Air blows in around 30C and
%   is cooled and then is passed back into the PLSS at 22 deg C
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Heat Pipe Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assumptions
% We are aiming for a delta T across the heat pipe evaporator wall to the
% radiator of about 3 deg K. So T_evap ~= 303K if T_rad = 300 which is what
% our I/O model used.
%  This entail buidling a resistance network of
% the evaporator section, the condensor section, and any bonding resistance
% to the shell. If we assume ideal bonding of the integrated saddle/HP, we
% can assume R bonding goes to zero. 
%
% The conductance values of the evaporator and condensor of the ammonia
% heat pipes are pulled from the graphs in source THE doc

N_loops = 5;                                    % # of heat pipes
Q.transport = min(Q.cooling_available);         % W; selected heat transport requirement
DeltaT_allow = 3;                               % K, design selection 

Q.pipe = Q.transport / N_loops;

pipe_diameters = [9.5; 12.7; 15.9]; %mm
Cprime_e = [120; 160; 200]; % W/mK Evaporator Conductance 
Cprime_c = [157; 214; 276]; % W/mK Condensor Conductance
pipe_lengths = linspace(0,1,101); % m
evap_length = 0.25*ones(1,101);%m about 12.5 cm
condensor_length = pipe_lengths-evap_length; % m

T_rad = 289.9; % Deg K which gives a drop of 5 deg from aveage skin temp 307k

% Calculate resistances including of the evaporator, condensor, and the
% bonds
R_evaporator = 1 ./ (Cprime_e .* evap_length); % Thermal resistance of the evaporator of the heat pipe
R_condensor = 1 ./ (Cprime_c .* condensor_length); % Thermal resistance of the condensor portion of HP

% Resistance of the adhesive bond (if selected)
% Integral pipe/flange, initially neglecting metal spreading resistance
b_contact = 20e-3;      % m; actual flat bonded width
L_contact = pipe_lengths;     % m
t_bond = 0.2e-3;       % m; thickness of adhesive
k_bond = 1;            % W/(m K); illustrative

A_contact = b_contact .* condensor_length;
R_attachment = t_bond ./ (k_bond .* A_contact);
R_bonds = [R_attachment; R_attachment; R_attachment];

Delta_T_sizing_options = Q.pipe.*(R_evaporator + R_condensor + R_bonds);
Delta_T_sizing_options_ideal = Q.pipe*(R_evaporator + R_condensor);

% Plot the results assuming an adhesive bond (Adds resistance to the
% network)
figure()
hold on
plot(condensor_length,Delta_T_sizing_options(1,:))
plot(condensor_length,Delta_T_sizing_options(2,:))
plot(condensor_length,Delta_T_sizing_options(3,:))
title('Heat-pipe temperature-drop sizing - Adhesive Bonding')
xlabel("Condensor Length [m]")
ylabel('Evaporator-wall to radiator temperature drop [K]')
legend('9.5 mm Diameter','12.7 mm Diameter','15.9 mm Diameter')
ylim([0 7])
xlim([0 .8])
grid on
hold off

% Plot the results assuming an ideal bond

figure()
hold on
plot(condensor_length,Delta_T_sizing_options_ideal(1,:))
plot(condensor_length,Delta_T_sizing_options_ideal(2,:))
plot(condensor_length,Delta_T_sizing_options_ideal(3,:))
title('Heat-pipe temperature-drop sizing - Ideally bonded')
xlabel("Condensor Length [m]")
ylabel('Evaporator-wall to radiator temperature drop [K]')
legend('9.5 mm Diameter','12.7 mm Diameter','15.9 mm Diameter')
ylim([0 7])
xlim([0 .8])
grid on
hold off


%% Freezable Heat Exchanger (Nitrogen/Water - Thermal)
% Assumptions
% T_LCG = 297K ~ 24C
% We want
% Q_HEX must match the Q_tranport which is the effective max load of
% cooling available given environmental conditions assuming a radiator
% surface temp
% We also want the delta T across the HEX to be about 2 deg K
rho_water = 1000;    %g/cm^3
Q.Hex = Q.transport;
T_LCG = 297;         % 24C

cp_water = 4180;     % J/(kg K)
Q.CHE = 130;         % W; assumed heat added to water


T_w_in = T_LCG;      % Assumed/Designed for
T_w_out = 283;       % 10 deg C
mdot_HEX = 90/3600;
%mdot_HEX = Q_Hex/(cp_water*(T_w_in-T_w_out));


% Candidate evaporator temperatures BELOW the desired water outlet
T_evap_surface = linspace(288.9-10,292.9-10,100);
T_rad_candidates = T_evap_surface - 3; % assumed downstream drop

% Calc Log mean temperature difference
DT_in = T_w_in - T_evap_surface;
DT_out = T_w_out - T_evap_surface;

feasible = (DT_in > 0) & (DT_out > 0);

Del_T_lm = nan(size(T_evap_surface));
Del_T_lm(feasible) = ...
    (DT_in(feasible) - DT_out(feasible)) ./ ...
    log(DT_in(feasible)./DT_out(feasible));

UA_required = Q.Hex./Del_T_lm;


R_we_allowable = Del_T_lm/Q.Hex; % K/W


L_water = 0.28;                  % m
k_water = 0.60;                  % W/(m K), at 34degC
k_Al= 237;                       % W/(m K)
mu_water = 0.80e-3;              % dynamic viscosity Pa*s = kg/(m*s), water at approximately 30°C

%Define characteristic lengths of the HEX geometry
r_fin = 0.5/1000;                % radius of fin edge m
h_fin = 4.9/1000;                % height of the fin m
b_fin = 1/1000;                  % base of the fin m
r_housing = 20/1000;             % radius of inner hole mm/meter 

A_fin = h_fin*L_water*2 + pi*r_fin*L_water;
A_housing = 2*pi*(r_housing)*L_water - 6*b_fin*L_water;

A_wetted = A_housing + A_fin;    % Contact Area water in the HEX 
fprintf('Wetted Area = %.2f m^2 \n', A_wetted)

% Check Reynolds number of pipe to determine flow characteristics
A_flow = pi*r_housing^2;
v_each = mdot_HEX/(rho_water*A_flow); % velocity of each pipe
Re = rho_water*v_each*2*r_housing/mu_water;     % Reynolds # of each pipe
fprintf('Reynolds Number = %.2f \n', Re)


if Re > 2300
    % Flow is turbulent: Calc Nu from turbulent pipe flow correlation
    nu = 1.08e-6; % kinematic viscosity of water at 17C
    alpha_diffusivity = 1.42e-7; % thermal diffusivity of water at 17C
    Pr = nu/alpha_diffusivity;
    Nu = (0.023)*Re^0.8 * Pr^0.4;
    fprintf('Flow through HEX is turbulent\n')
    fprintf('Prandtl Number = %.2f \n', Pr)
    fprintf('Nusselt Number = %.2f \n', Nu)


    else
    % Flow is laminar: use the fully developed circular-tube correlation
    fprintf('Flow through HEX is laminar\n')

    Nu = 3.66;
    fprintf('Nusselt Number = %.2f \n', Nu)

end

h_water = Nu*k_water/(2*r_housing);               % heat transfer coefficient for convection through the water pipes
fprintf('HEX Water Convective HTC = %.2f W/(m^2 K)(\n', h_water)

R_conv = 1./(h_water*A_wetted);              % Convective Resistance in the HEX
fprintf('HEX Convective thermal resistance = %.2f K/W \n', R_conv)

% Calc Effective resistance of the Aluminum to evap pipes
t_Al = 1e-3;  % thickness of aluminum            
A_eff = A_wetted;             

R_Al = t_Al./(k_Al.*A_eff);
fprintf('HEX Aluminum thermal resistance = %.2f K/W \n', R_Al)
% Other Resistances not modeled. 
% Heat Pipe Contact Resistance
% Copper spreading resistance

R_total = R_conv + R_Al;
fprintf('HEX total thermal resistance = %.2f K/W \n', R_total)

U_A = 1./R_total;   
fprintf('U_A = Overall HTC*Area = %.2f W/K \n', U_A)

%% Condesing Heat Exchanger (Water/Air - RH)

% Questions for Operation
% Where is the cooling coming from to bring the Air temp down to 12C? If
% air enters at 30C , our exit temp from the HEX is only 304.49

fprintf('Condensing Heat Exchanger Analysis\n');

Q_CHE = 80; % W
cp_air = 1000; % J/kgK
T_air_in = 30+273; % Deg K
T_air_out = 12+273; % Deg K
DT_air = T_air_in-T_air_out;
DT_water = T_LCG - T_w_out(end);

mdot_air = Q_CHE/(cp_air*DT_air);
mdot_water = Q_CHE/(cp_water*DT_water);

fprintf('Mass flow rate of air through CHE: %.4f kg/hr\n', mdot_air*3600);
fprintf('Mass flow rate of water through CHE: %.4f kg/hr\n', mdot_water*3600);


% Ignoring CHE for now

% mdot_total = 90/3600;          % kg/s; example TOTAL HEX flow
% f_CHE = 0.20;                  % illustrative flow fraction, not selected sizing
% 
% mdot_CHE = f_CHE * mdot_total;
% mdot_LCG = (1 - f_CHE) * mdot_total;
% 
% % Supply these temperatures from your model:
% T_HEXw_out = T_LCG - Q_Hex/(mdot_total *cp_water); %cold water leaving HEX [K]
% T_LCG_out = 307; %warm water leaving LCG [K]
% 
% T_CHE_out = T_HEX_out + Q_CHE/(mdot_CHE*cp_water);
% 
% T_HEX_in = ...
%     (mdot_LCG*T_LCG_out + mdot_CHE*T_CHE_out)/mdot_total;
% 
% Q_HEX = mdot_total*cp_water*(T_HEX_in - T_HEX_out);





% %% Part Two Re-routed: System-Dictated Radiator Temperature Analysis
% T_w_in_C = 24;                              % Desired LCG return / HEX water inlet temp [C]
% T_w_out_C_options = [12, 14, 16, 18];       % Target water output temperatures [C]
% cp_water = 4184;                            % J/(kg K)
% mdot_water = mdot_HEX(end);                 % Design mass flow rate [kg/s]
% 
% % --- Use scalar totals from Part 0 to avoid vector mismatch ---
% A_rad_fixed = Arad;                         % Total radiator area [m^2] (scalar from Part 0)
% epsilon_rad = 0.9;                          % Radiator IR emissivity
% alpha_solar = 0.17;                         % Solar absorptivity
% q_solar_DNI = 175;                          % W/m^2
% 
% % Scalar environmental incident fluxes (using weighted areas from Part 0)
% % Total absorbed environmental IR (Ground IR + Sky IR)
% Q_ground_IR_absorbed = alpha_IR * epsilon_ground * sigma * T_ground^4 * A_ground_weighted;
% Q_sky_IR_absorbed = alpha_IR * sigma * T_sky^4 * A_sky_weighted;
% Q_total_IR_abs = Q_ground_IR_absorbed + Q_sky_IR_absorbed;
% 
% % Simplified direct solar load (using average cross-sectional area from Part 0)
% Q_solar_absorbed = alpha_solar * mean(Q_solar); 
% 
% fprintf("=== SYSTEM-DICTATED RADIATOR TEMPERATURE & CAPACITY ANALYSIS ===\n");
% 
% for i = 1:length(T_w_out_C_options)
%     T_w_out_C = T_w_out_C_options(i);
% 
%     % 1. Calculate required heat removal for this water drop [Watts]
%     Delta_T_water = (T_w_in_C - T_w_out_C);
%     Q_required = mdot_water * cp_water * Delta_T_water; 
% 
%     % 2. Define anonymous function for fzero (guaranteed scalar)
%     % T_rad is the scalar variable being solved for.
%     fun = @(T_rad) ( ...
%         (epsilon_rad * sigma * A_rad_fixed * T_rad^4) ...         % Gross IR emission
%         + (h * A_rad_fixed * (T_rad - T_air)) ...                 % Convection loss
%         - Q_total_IR_abs ...                                      % Minus absorbed thermal IR
%         - Q_solar_absorbed ...                                    % Minus absorbed solar/albedo
%         - Q_required );                                           % Minus internal heat load to balance
% 
%     % 3. Solve for scalar equilibrium T_rad [K]
%     T_w_mean = (T_w_in_C + T_w_out_C)/2 + 273.15;                 % Mean water temp [K]
%     T_rad_guess = T_w_mean - 5;                                   % Initial guess
% 
%     T_rad_solution = fzero(fun, T_rad_guess);
% 
%     % 4. Print results
%     fprintf("Target Water Out: %d °C | Required Q: %.2f W | Equilibrium T_rad: %.2f K (%.2f °C)\n", ...
%         T_w_out_C, Q_required, T_rad_solution, T_rad_solution - 273.15);
% end
% 
% %% Fully Coupled Analysis: Water Temp vs. Radiator Temp via Internal Resistance
% Q_metabolic = 300;                          % Constant heat load from astronaut [W]
% T_w_in_C = 24;                              % LCG return temp [C]
% T_w_out_C_options = [12, 14, 16, 18];       % Target water output temperatures [C]
% 
% A_rad_fixed = Arad;                         % Scalar radiator area
% epsilon_rad = 0.9;                          
% alpha_solar = 0.17;                         
% 
% % Environment absorption terms
% Q_total_IR_abs = (alpha_IR * epsilon_ground * sigma * T_ground^4 * A_ground_weighted) + ...
%                  (alpha_IR * sigma * T_sky^4 * A_sky_weighted);
% Q_solar_absorbed = alpha_solar * mean(Q_solar);   
% 
% % Use your actual computed R_total from your HEX/heat pipe analysis (e.g., R_total(end))
% % If you want a placeholder for testing, we can assume a typical net resistance ~0.015 K/W:
% R_internal = 0.015;                         % [K/W] (Replace with your actual R_total variable if available)
% 
% fprintf("=== FULLY COUPLED WATER-TO-RADIATOR ANALYSIS (300W Load) ===\n");
% 
% for i = 1:length(T_w_out_C_options)
%     T_w_out_C = T_w_out_C_options(i);
% 
%     % 1. Calculate mean water temperature across the HEX
%     T_w_mean_C = (T_w_in_C + T_w_out_C) / 2;     
%     T_w_mean_K = T_w_mean_C + 273.15;            
% 
%     % 2. Derive Radiator Temperature based on internal resistance drop
%     % T_rad must sit lower than the water by (Q * R_internal)
%     T_rad_coupled = T_w_mean_K - (Q_metabolic * R_internal);
% 
%     % 3. Check what heat the radiator can actually reject to the environment at this T_rad
%     Q_rejected_env = (epsilon_rad * sigma * A_rad_fixed * T_rad_coupled^4) ... 
%                    + (h * A_rad_fixed * (T_rad_coupled - T_air)) ...         
%                    - Q_total_IR_abs ...                              
%                    - Q_solar_absorbed;
% 
%     fprintf("Target Out: %2d °C | Mean Water: %4.1f °C | Resulting T_rad: [1m%6.2f K[0m (%5.2f °C) | Env Rejection: %.2f W\n", ...
%         T_w_out_C, T_w_mean_C, T_rad_coupled, T_rad_coupled - 273.15, Q_rejected_env);
% end


%% Pipe Flow (Convective losses in the PLSS)

%% Pumps (Account for frictional and heating effects from the pump)
% DeltaPressure = 14;
% % Can also use an equivalent expression 
% Power_pump = DeltaPressure*mdot/(rho_water*pump_efficiency);
% % Use voltage and current from the pump's operating point
% P_pump_elec = V_pump * I_pump;       % W
% 
% % Preliminary assumption: all pump power heats the water loop
% Q_pump_water = P_pump_elec;
% 
% % Add once to the water-loop heat rejection requirement
% Q_HEX_required = Q_other_water_loads + Q_pump_water;
% 
% % Equivalent temperature rise per circuit
% mdot_water = 90/3600;               % kg/s; use actual operating flow
% DT_pump_equiv = Q_pump_water/(mdot_water*cp_water);
% 
% % Pressure losses across the system due to frictional in the pipes
% 
% v = mdot_water/(rho_water*pi*D_line^2/4);
% Re = rho_water*v*D_line/mu_water;
% 
% f_D = 64/Re;  % Only for fully developed laminar flow
% 
% DP_pipe = f_D*(L_line/D_line)*(rho_water*v^2/2);
% DP_fittings = K_total*(rho_water*v^2/2);
% 
% Q_friction_line = (DP_pipe + DP_fittings) * ...
%                  (mdot_water/rho_water); % W; diagnostic, already within pump budget

%% Valves (Minimal)

%% Air Warmer

%% Suit Radiator
% The results from the previous section will be used at inputs fro this
% section. Heat that is trasnferred from the pipes to our radiator
% will be modeled. Thereafter, 1D heat transfer will be applied across the
% radiator, and the radiative, conductive, and convective heat rejection
% into the Martian atmosphere will be measured. 


A_suit_rad = linspace(0.2,1,100);           % m^2
epsilon_suit_pixels = linspace(0.3,0.8,100);
alpha_solar = 0.17;
epsilon_ground = 0.95;
sigma = 5.670374419e-8; % W/(m^2 K^4)
T_ground = 235; % K; prescribed ground-temperature scenario
T_air = 210;    % K; prescribed air-temperature scenario
T_sky = 170;    % K; EFFECTIVE radiative sky temperature
q_solar_DNI = 175; % W/m^2

% Same assumed temperature as RAFT-X radiator
T_suit_rad = T_rad;                        % K

% Illustrative vertical surface over flat terrain
F_ground = 0.5;
F_sky = 0.5;

% Incident thermal IR, BEFORE absorption by the pixels
G_IR = F_ground*epsilon_ground*sigma*T_ground^4 ...
     + F_sky*sigma*T_sky^4;                % W/m^2

% Assumes surface directly faces the Sun.
% Replace with actual incident solar irradiance for its orientation.
G_solar = q_solar_DNI;                     % W/m^2

% Evaluate every area/emissivity combination
[A_grid, epsilon_grid] = meshgrid( ...
    A_suit_rad, epsilon_suit_pixels);

% Positive = net heat rejection
% Assumes thermal-IR absorptivity equals thermal emissivity
Qout_suit = A_grid .* ...
    (epsilon_grid .* (sigma*T_suit_rad^4 - G_IR) ...
    - alpha_solar*G_solar);

Q.radiative_net = A_grid .* ...
    (epsilon_grid .* (sigma*T_suit_rad^4 - G_IR) ...
    - alpha_solar*G_solar);

Q.conv_suit = envir_const.h*A_grid*(T_suit_rad - T_air);

Q_total_suit = Q.radiative_net + Q.conv_suit;
% Subtract absorbed albedo when included.

% Plot several fixed epsilon values for a given area
figure
contourf(A_grid, epsilon_grid, Qout_suit, ...
    30, 'LineColor', 'none');

cb = colorbar;
cb.Label.String = 'Net heat rejection [W]';

xlabel('Suit radiator area [m^2]');
ylabel('Pixel infrared emissivity');
title(sprintf('Suit radiator capacity at %.2f K', T_suit_rad));
colormap(turbo)
grid on

figure
hold on

for epsilon = [0.3 0.5 0.8]
    Q = A_suit_rad .* ...
        (epsilon*(sigma*T_suit_rad^4 - G_IR) ...
        - alpha_solar*G_solar);

    plot(A_suit_rad, Q, 'LineWidth', 2, ...
        'DisplayName', sprintf('\\epsilon = %.1f', epsilon));
end

yline(0, 'k--', 'HandleVisibility', 'off');
xlabel('Suit radiator area [m^2]');
ylabel('Net heat rejection [W]');
title('Suit radiator capacity versus area');
legend('Location', 'best');
grid on
hold off


%% Functions 

function [Q, theta] = radiator_output(T_Rad, const, rad_specs, envir_const, Q)


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Direct solar heating  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Idealized 2D Sun path, not a calculated Mars time history:
    % 0 deg = Sun at rear horizon
    % 90 deg = overhead
    % 180 deg = Sun at front horizon
    theta = linspace(0,180,181); % Row vector
    A_rad_cross = rad_specs.H*rad_specs.W .* max(0, cosd(theta)) ...
                + rad_specs.W*rad_specs.D .* sind(theta); 
    Q.solar = rad_specs.alpha_solar .* A_rad_cross .* envir_const.q_solar_DNI;
    fprintf("Average direct normal incident Solar is %.2f Watts\n",mean(Q.solar))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Reflected solar heating: albedo
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Direct sunlight on horizontal ground; diffuse sunlight neglected
    G_solar_ground = envir_const.q_solar_DNI .* sind(theta);
    
    Q.albedo = rad_specs.alpha_solar .* envir_const.rho_ground .* ...
               G_solar_ground .* rad_specs.A_ground_weighted;
    fprintf("Albedo is %.2f Watts\n",mean(Q.albedo))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Absorbed thermal infrared
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Ground emission only; reflected atmospheric IR neglected
    Q.ground_IR_abs = envir_const.alpha_IR * envir_const.epsilon_ground * ...
                        const.sigma * envir_const.T_ground^4 * rad_specs.A_ground_weighted;
    
    fprintf("Ground IR is %.2f Watts\n",mean(Q.ground_IR_abs))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Effective sky temperature represents incident sky IR
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    Q.sky_IR_abs = envir_const.alpha_IR * const.sigma * ...
                   envir_const.T_sky^4 * rad_specs.A_sky_weighted;
    fprintf("Sky IR is %.2f Watts\n",mean(Q.sky_IR_abs))
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Heat leaving radiator
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    Q.conv = envir_const.h * rad_specs.Arad * (T_Rad - envir_const.T_air); % Signed: positive outward
    fprintf("Heat lost to Atmospheric Convection assuming 5 m/s windspeed is %.2f Watts\n",Q.conv)
    
    Q.IR_emit = rad_specs.epsilon_rad * const.sigma * rad_specs.Arad * T_Rad^4;
    fprintf("IR emitted from  the radiator is %.2f Watts\n",Q.IR_emit)
    fprintf("\n")
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % System balance
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Net heat that the radiator can remove from internal sources
    % One value per solar-position case
    Q.cooling_available = Q.IR_emit + Q.conv ...
                        - Q.solar - Q.albedo ...
                        - Q.ground_IR_abs - Q.sky_IR_abs;
    fprintf("Average Cooling available is %.2f Watts\n",mean(Q.cooling_available))
    
    Q.cooling_available_nowind = Q.cooling_available - Q.conv;
    fprintf("Average Cooling available is %.2f Watts\n",mean(Q.cooling_available_nowind))
    fprintf("\n")

end